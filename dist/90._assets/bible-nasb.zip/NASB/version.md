---
name: New American Standard Bible
id: NASB
version: 1995
language: en
copyright: All rights reserved.
---
