---
name: Nova Almeida Atualizada
id: NAA
version: 1.0.0
language: pt-BR
copyright: Todos os direitos reservados.
---
