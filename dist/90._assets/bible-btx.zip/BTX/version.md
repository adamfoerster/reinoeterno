---
name: Biblia Textual
id: BTX
version: 1.0.0
language: es
copyright: Todos os direitos reservados.
---
