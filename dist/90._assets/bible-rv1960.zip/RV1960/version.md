---
name: Reina Valera 1960
id: RV1960
version: 1960
language: es
copyright: Todos os direitos reservados.
---
