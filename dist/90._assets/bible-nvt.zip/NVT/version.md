---
name: Nova Versão Transformadora
id: NVT
version: 1.0.0
language: pt-BR
copyright: Todos os direitos reservados.
---
